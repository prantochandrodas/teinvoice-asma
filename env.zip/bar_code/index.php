
<img src="http://localhost/bar_code/code.php?code=Bidhan" width="200px"/>